import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Award,
  Users,
  Globe,
  Target,
  Heart,
  Lightbulb,
  TrendingUp,
  CheckCircle2,
  ArrowRight,
  Zap,
  Handshake,
  Shield,
  Clock,
} from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden bg-gradient-to-br from-slate-950 via-violet-950 to-slate-950">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(139, 92, 246, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(139, 92, 246, 0.3) 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }}></div>
      </div>
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-violet-600/30 rounded-full blur-[128px]"></div>

      <div className="mx-auto max-w-7xl px-6 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <span className="inline-block px-4 py-2 bg-white/10 text-white rounded-full text-sm font-semibold mb-4">
            About NexaTech
          </span>
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
            Pioneering the Future of{' '}
            <span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              Digital Excellence
            </span>
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Since 2012, we've been at the forefront of digital transformation, helping businesses navigate the ever-evolving technological landscape.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

const StorySection = () => {
  return (
    <section className="py-32 bg-white">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="inline-block px-4 py-2 bg-violet-100 text-violet-600 rounded-full text-sm font-semibold mb-4">
              Our Story
            </span>
            <h2 className="text-4xl font-bold text-slate-900 mb-6">
              From Startup to{' '}
              <span className="bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                Industry Leader
              </span>
            </h2>
            <div className="space-y-6 text-slate-600 leading-relaxed">
              <p>
                Founded in 2012 by a team of passionate technologists and marketers, NexaTech began with a simple mission: to bridge the gap between technology and business success.
              </p>
              <p>
                What started as a small team of 5 has grown into a global force of 200+ professionals, serving clients across 30+ countries. Our journey has been marked by continuous innovation, unwavering commitment to quality, and a deep understanding of what drives business growth.
              </p>
              <p>
                Today, we're recognized as industry leaders, having delivered over 500 successful projects and helped our clients achieve an average ROI of 250%. But our greatest achievement remains the lasting partnerships we've built with our clients.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-violet-500/30">
              <img
                src="/images/about-team.jpg"
                alt="NexaTech Team"
                className="w-full aspect-square object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-violet-900/80 to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8 text-white">
                <div className="text-5xl font-bold mb-2">12+</div>
                <div className="text-lg opacity-90">Years of Excellence</div>
              </div>
            </div>
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute -bottom-8 -left-8 bg-white rounded-2xl p-6 shadow-xl"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-100 rounded-xl">
                  <TrendingUp className="h-6 w-6 text-emerald-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-900">250%</div>
                  <div className="text-sm text-slate-600">Average ROI</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const MissionVision = () => {
  return (
    <section className="py-32 bg-gradient-to-br from-slate-50 to-violet-50">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white rounded-3xl p-10 shadow-xl"
          >
            <div className="p-4 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl w-fit mb-6">
              <Target className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Mission</h3>
            <p className="text-slate-600 leading-relaxed">
              To empower businesses with innovative technology solutions and strategic marketing initiatives that drive sustainable growth, enhance customer experiences, and create lasting value in an increasingly digital world.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-3xl p-10 shadow-xl"
          >
            <div className="p-4 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-2xl w-fit mb-6">
              <Lightbulb className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-4">Our Vision</h3>
            <p className="text-slate-600 leading-relaxed">
              To be the global leader in digital transformation, recognized for our innovation, expertise, and unwavering commitment to client success. We envision a future where technology seamlessly integrates with business strategy.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const ValuesSection = () => {
  const values = [
    { icon: Lightbulb, title: 'Innovation', description: 'We stay ahead of the curve, embracing new technologies and creative solutions.' },
    { icon: Handshake, title: 'Integrity', description: 'We build relationships on trust, transparency, and honest communication.' },
    { icon: Heart, title: 'Passion', description: 'We love what we do, and it shows in every project we deliver.' },
    { icon: Users, title: 'Collaboration', description: 'We work as an extension of your team, sharing your vision and goals.' },
    { icon: Shield, title: 'Quality', description: 'We never compromise on quality, delivering excellence in every detail.' },
    { icon: Clock, title: 'Reliability', description: 'We deliver on time, every time, meeting and exceeding expectations.' },
  ];

  return (
    <section className="py-32 bg-white">
      <div className="mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <span className="inline-block px-4 py-2 bg-emerald-100 text-emerald-600 rounded-full text-sm font-semibold mb-4">
            Our Values
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            What We{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Stand For</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-3xl bg-gradient-to-br from-slate-50 to-white border border-slate-100 hover:border-violet-200 hover:shadow-xl transition-all duration-300"
            >
              <div className="p-4 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl w-fit mb-6">
                <value.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{value.title}</h3>
              <p className="text-slate-600 leading-relaxed">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const StatsSection = () => {
  const stats = [
    { value: '500+', label: 'Projects Completed', icon: CheckCircle2 },
    { value: '200+', label: 'Team Members', icon: Users },
    { value: '30+', label: 'Countries Served', icon: Globe },
    { value: '98%', label: 'Client Satisfaction', icon: Award },
  ];

  return (
    <section className="py-20 bg-gradient-to-r from-violet-600 to-fuchsia-600">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <stat.icon className="h-8 w-8 text-white/80 mx-auto mb-4" />
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-white/80">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CTASection = () => {
  return (
    <section className="py-32 bg-gradient-to-br from-slate-50 to-violet-50">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <Zap className="h-12 w-12 text-violet-600 mx-auto mb-6" />
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Let's Build Something Great Together
          </h2>
          <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
            Ready to take your business to the next level? Contact us today for a free consultation.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold rounded-full shadow-lg shadow-violet-500/30 flex items-center gap-2"
              >
                Get in Touch <ArrowRight className="h-5 w-5" />
              </motion.button>
            </Link>
            <Link to="/services">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white text-slate-900 font-semibold rounded-full shadow-lg"
              >
                Explore Services
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default function About() {
  return (
    <>
      <HeroSection />
      <StorySection />
      <MissionVision />
      <ValuesSection />
      <StatsSection />
      <CTASection />
    </>
  );
}
