import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Code2,
  Megaphone,
  Smartphone,
  Shield,
  Cloud,
  BarChart3,
  ArrowRight,
  Check,
  Zap,
  Globe,
} from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden bg-gradient-to-br from-slate-950 via-violet-950 to-slate-950">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(139, 92, 246, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(139, 92, 246, 0.3) 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }}></div>
      </div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-600/30 rounded-full blur-[128px]"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-fuchsia-600/30 rounded-full blur-[128px]"></div>

      <div className="mx-auto max-w-7xl px-6 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <span className="inline-block px-4 py-2 bg-white/10 text-white rounded-full text-sm font-semibold mb-4">
            Our Services
          </span>
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
            Comprehensive{' '}
            <span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              Digital Solutions
            </span>
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            From custom software development to data-driven marketing, we offer end-to-end solutions to transform your business.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

const ServicesList = () => {
  const services = [
    {
      icon: Code2,
      title: 'Web Development',
      description: 'Custom websites and web applications built with cutting-edge technologies.',
      features: ['Full-Stack Development', 'E-Commerce Solutions', 'CMS Development', 'Progressive Web Apps', 'API Development', 'Legacy System Modernization'],
      gradient: 'from-violet-500 to-purple-600',
      link: '/services/web-development',
      image: '/images/services-web.jpg',
    },
    {
      icon: Smartphone,
      title: 'Mobile App Development',
      description: 'Native and cross-platform mobile applications for iOS and Android.',
      features: ['iOS Development', 'Android Development', 'React Native', 'Flutter Apps', 'App Store Optimization', 'Maintenance & Support'],
      gradient: 'from-fuchsia-500 to-pink-600',
      link: '/services/mobile-apps',
      image: '/images/services-mobile.jpg',
    },
    {
      icon: Megaphone,
      title: 'Digital Marketing',
      description: 'Data-driven marketing strategies that deliver measurable results.',
      features: ['SEO & SEM', 'Social Media Marketing', 'Content Marketing', 'Email Marketing', 'PPC Campaigns', 'Analytics & Reporting'],
      gradient: 'from-cyan-500 to-blue-600',
      link: '/services/digital-marketing',
      image: '/images/portfolio-3.jpg',
    },
    {
      icon: Cloud,
      title: 'Cloud Solutions',
      description: 'Scalable cloud infrastructure and migration services.',
      features: ['Cloud Migration', 'AWS/Azure/GCP', 'DevOps', 'Kubernetes', 'Serverless Architecture', 'Cloud Security'],
      gradient: 'from-emerald-500 to-teal-600',
      link: '/services/cloud-solutions',
      image: '/images/services-cloud.jpg',
    },
    {
      icon: Shield,
      title: 'Cybersecurity',
      description: 'Protect your digital assets with comprehensive security solutions.',
      features: ['Penetration Testing', 'Security Audits', 'Compliance', 'Incident Response', 'Security Training', 'Zero Trust Architecture'],
      gradient: 'from-orange-500 to-red-600',
      link: '/services/cybersecurity',
      image: '/images/services-web.jpg',
    },
    {
      icon: BarChart3,
      title: 'AI & Analytics',
      description: 'Unlock insights with advanced analytics and AI-powered solutions.',
      features: ['Machine Learning', 'Predictive Analytics', 'Business Intelligence', 'Data Engineering', 'NLP Solutions', 'Computer Vision'],
      gradient: 'from-indigo-500 to-blue-600',
      link: '/services/ai-analytics',
      image: '/images/portfolio-1.jpg',
    },
  ];

  return (
    <section className="py-32 bg-white">
      <div className="mx-auto max-w-7xl px-6">
        <div className="space-y-20">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`grid lg:grid-cols-2 gap-16 items-center ${
                index % 2 !== 0 ? 'lg:flex-row-reverse' : ''
              }`}
            >
              <div className={index % 2 !== 0 ? 'lg:order-2' : ''}>
                <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${service.gradient} shadow-lg mb-6`}>
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mb-4">
                  {service.title}
                </h2>
                <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-4 mb-8">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <div className="p-1 bg-violet-100 rounded-full">
                        <Check className="h-4 w-4 text-violet-600" />
                      </div>
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to={service.link}>
                  <motion.button
                    whileHover={{ scale: 1.05, x: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold rounded-full shadow-lg shadow-violet-500/30"
                  >
                    Learn More <ArrowRight className="h-5 w-5" />
                  </motion.button>
                </Link>
              </div>

              <div className={index % 2 !== 0 ? 'lg:order-1' : ''}>
                <div className="relative rounded-3xl overflow-hidden aspect-square">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-60`}></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div
                      animate={{ y: [0, -15, 0] }}
                      transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <service.icon className="h-32 w-32 text-white/80" />
                    </motion.div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ProcessSection = () => {
  const steps = [
    { step: '01', title: 'Discovery', description: 'We learn about your business, goals, and challenges to understand your unique needs.' },
    { step: '02', title: 'Strategy', description: 'We develop a comprehensive plan tailored to achieve your objectives.' },
    { step: '03', title: 'Development', description: 'Our expert team brings the strategy to life with cutting-edge technology.' },
    { step: '04', title: 'Launch', description: 'We deploy your solution and ensure everything runs smoothly.' },
    { step: '05', title: 'Support', description: 'Ongoing maintenance and optimization to keep you ahead.' },
  ];

  return (
    <section className="py-32 bg-gradient-to-br from-slate-50 to-violet-50">
      <div className="mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <span className="inline-block px-4 py-2 bg-violet-100 text-violet-600 rounded-full text-sm font-semibold mb-4">
            Our Process
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            How We{' '}
            <span className="bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">Work</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-5 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              <div className="text-6xl font-bold bg-gradient-to-r from-violet-200 to-fuchsia-200 bg-clip-text text-transparent mb-4">
                {step.step}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
              <p className="text-slate-600">{step.description}</p>
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-violet-200 to-transparent"></div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => {
  const industries = [
    'Healthcare', 'Finance', 'Retail', 'Education', 'Manufacturing', 'Real Estate', 'Travel', 'Entertainment',
  ];

  return (
    <section className="py-32 bg-white">
      <div className="mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 bg-emerald-100 text-emerald-600 rounded-full text-sm font-semibold mb-4">
            Industries
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            Industries We{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Serve</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            We have deep expertise across various industries, understanding unique challenges and opportunities.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="p-8 bg-gradient-to-br from-slate-50 to-white rounded-2xl border border-slate-100 hover:border-violet-200 hover:shadow-xl transition-all duration-300 text-center"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-white" />
              </div>
              <h3 className="font-semibold text-slate-900">{industry}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CTASection = () => {
  return (
    <section className="py-32 bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-600 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
      }}></div>

      <div className="mx-auto max-w-4xl px-6 text-center relative">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <Zap className="h-12 w-12 text-white mx-auto mb-6" />
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-white/80 mb-10 max-w-2xl mx-auto">
            Let's discuss how our services can help transform your business and achieve your goals.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-10 py-5 bg-white text-violet-600 font-bold rounded-full shadow-xl flex items-center gap-2"
              >
                Get Free Consultation <ArrowRight className="h-5 w-5" />
              </motion.button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default function Services() {
  return (
    <>
      <HeroSection />
      <ServicesList />
      <ProcessSection />
      <IndustriesSection />
      <CTASection />
    </>
  );
}
