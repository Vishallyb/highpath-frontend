import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, User, ArrowRight, Search, Tag, Calendar } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden bg-gradient-to-br from-slate-950 via-violet-950 to-slate-950">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(139, 92, 246, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(139, 92, 246, 0.3) 1px, transparent 1px)',
          backgroundSize: '50px 50px',
        }}></div>
      </div>

      <div className="mx-auto max-w-7xl px-6 relative">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <span className="inline-block px-4 py-2 bg-white/10 text-white rounded-full text-sm font-semibold mb-4">
            Blog & Insights
          </span>
          <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
            Latest{' '}
            <span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              Insights
            </span>
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Stay updated with the latest trends, insights, and news from the world of technology and digital marketing.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

const BlogGrid = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const categories = ['all', 'technology', 'marketing', 'design', 'business', 'tutorial'];

  const posts = [
    {
      id: 1,
      title: 'The Future of AI in Enterprise Applications',
      category: 'technology',
      excerpt: 'Explore how artificial intelligence is transforming business operations and what it means for your organization.',
      author: 'Sarah Chen',
      date: 'Dec 15, 2024',
      readTime: '8 min read',
      image: '/images/services-web.jpg',
      featured: true,
    },
    {
      id: 2,
      title: '10 Digital Marketing Trends to Watch in 2025',
      category: 'marketing',
      excerpt: 'Stay ahead of the curve with these emerging marketing trends that will shape the industry.',
      author: 'Michael Rivera',
      date: 'Dec 12, 2024',
      readTime: '6 min read',
      image: '/images/portfolio-3.jpg',
      featured: false,
    },
    {
      id: 3,
      title: 'Building Scalable Microservices Architecture',
      category: 'tutorial',
      excerpt: 'A comprehensive guide to designing and implementing microservices for enterprise applications.',
      author: 'Alex Mitchell',
      date: 'Dec 10, 2024',
      readTime: '12 min read',
      image: '/images/portfolio-1.jpg',
      featured: false,
    },
    {
      id: 4,
      title: 'The Art of Minimalist UI Design',
      category: 'design',
      excerpt: 'How less can truly be more when it comes to creating impactful user interfaces.',
      author: 'Emily Zhang',
      date: 'Dec 8, 2024',
      readTime: '5 min read',
      image: '/images/portfolio-2.jpg',
      featured: false,
    },
    {
      id: 5,
      title: 'Digital Transformation Strategies for Startups',
      category: 'business',
      excerpt: 'Essential strategies for startups looking to leverage technology for growth.',
      author: 'Michael Rivera',
      date: 'Dec 5, 2024',
      readTime: '7 min read',
      image: '/images/about-team.jpg',
      featured: false,
    },
    {
      id: 6,
      title: 'React Performance Optimization Techniques',
      category: 'tutorial',
      excerpt: 'Advanced techniques to make your React applications lightning fast.',
      author: 'Sarah Chen',
      date: 'Dec 3, 2024',
      readTime: '10 min read',
      image: '/images/services-web.jpg',
      featured: false,
    },
    {
      id: 7,
      title: 'Social Media ROI: Measuring What Matters',
      category: 'marketing',
      excerpt: 'A data-driven approach to measuring and improving your social media returns.',
      author: 'Michael Rivera',
      date: 'Dec 1, 2024',
      readTime: '6 min read',
      image: '/images/portfolio-3.jpg',
      featured: false,
    },
    {
      id: 8,
      title: 'Cloud Native Development Best Practices',
      category: 'technology',
      excerpt: 'Best practices for building applications designed for the cloud from day one.',
      author: 'Alex Mitchell',
      date: 'Nov 28, 2024',
      readTime: '9 min read',
      image: '/images/services-cloud.jpg',
      featured: false,
    },
  ];

  const filteredPosts = activeCategory === 'all'
    ? posts
    : posts.filter(p => p.category === activeCategory);

  const featuredPost = posts.find(p => p.featured);
  const regularPosts = filteredPosts.filter(p => !p.featured);

  return (
    <section className="py-32 bg-white">
      <div className="mx-auto max-w-7xl px-6">
        {/* Search and Filters */}
        <div className="mb-12 space-y-6">
          {/* Search Bar */}
          <div className="relative max-w-xl mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search articles..."
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2 rounded-full font-medium transition-all duration-300 capitalize text-sm ${
                  activeCategory === category
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white shadow-lg shadow-violet-500/30'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Post */}
        {featuredPost && activeCategory === 'all' && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16"
          >
            <div className="grid lg:grid-cols-2 gap-8 bg-gradient-to-br from-slate-50 to-violet-50 rounded-3xl overflow-hidden">
              <div className="relative aspect-video lg:aspect-auto">
                <img
                  src={featuredPost.image}
                  alt={featuredPost.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 px-4 py-2 bg-violet-600 text-white rounded-full text-sm font-semibold">
                  Featured
                </div>
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <span className="inline-flex items-center gap-2 text-sm font-medium text-violet-600 mb-4">
                  <Tag className="h-4 w-4" /> {featuredPost.category}
                </span>
                <h2 className="text-2xl lg:text-3xl font-bold text-slate-900 mb-4 hover:text-violet-600 transition-colors">
                  {featuredPost.title}
                </h2>
                <p className="text-slate-600 mb-6 leading-relaxed">{featuredPost.excerpt}</p>
                <div className="flex items-center gap-6 text-sm text-slate-500 mb-6">
                  <span className="flex items-center gap-2">
                    <User className="h-4 w-4" /> {featuredPost.author}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" /> {featuredPost.date}
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock className="h-4 w-4" /> {featuredPost.readTime}
                  </span>
                </div>
                <button className="inline-flex items-center gap-2 text-violet-600 font-semibold hover:gap-3 transition-all">
                  Read Article <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="wait">
            {regularPosts.map((post, index) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 30 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="group"
              >
                <div className="bg-white rounded-3xl overflow-hidden shadow-xl shadow-slate-200/50 hover:shadow-2xl hover:shadow-violet-200/50 transition-all duration-500 h-full">
                  {/* Post Image */}
                  <div className="aspect-video relative overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>

                  {/* Post Content */}
                  <div className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <span className="px-3 py-1 bg-violet-100 text-violet-600 rounded-full text-xs font-medium capitalize">
                        {post.category}
                      </span>
                      <span className="text-sm text-slate-500 flex items-center gap-1">
                        <Clock className="h-4 w-4" /> {post.readTime}
                      </span>
                    </div>

                    <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-violet-600 transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-slate-600 mb-4 line-clamp-2">{post.excerpt}</p>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                          {post.author.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-900">{post.author}</div>
                          <div className="text-xs text-slate-500">{post.date}</div>
                        </div>
                      </div>
                      <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-violet-600 group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-slate-100 text-slate-900 font-semibold rounded-full hover:bg-slate-200 transition-colors"
          >
            Load More Articles
          </motion.button>
        </div>
      </div>
    </section>
  );
};

const NewsletterSection = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-violet-600 to-fuchsia-600">
      <div className="mx-auto max-w-4xl px-6 text-center">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Subscribe to Our Newsletter
          </h2>
          <p className="text-white/80 mb-8">
            Get the latest insights delivered straight to your inbox.
          </p>
          <div className="flex gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-6 py-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-white"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-white text-violet-600 font-bold rounded-xl"
            >
              Subscribe
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default function Blog() {
  return (
    <>
      <HeroSection />
      <BlogGrid />
      <NewsletterSection />
    </>
  );
}
